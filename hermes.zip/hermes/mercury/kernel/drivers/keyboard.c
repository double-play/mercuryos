/* ─── Mercury OS ─ kernel/drivers/keyboard.c ─────────────────────────── */

#include "keyboard.h"
#include "../mercury.h"
#include "../cpu/idt.h"

#define KBD_DATA    0x60
#define KBD_STATUS  0x64

/* ── US QWERTY scancode set 1 → ASCII ───────────────────────────────── */
static const char scancode_table[128] = {
    0,    27,  '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '-',  '=',
    '\b', '\t','q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p', '[',  ']',
    '\n', 0,   'a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', ';', '\'', '`',
    0,    '\\','z', 'x', 'c', 'v', 'b', 'n', 'm', ',', '.', '/', 0,    '*',
    0,    ' ',
    /* 0x3A–0x7F: function keys, arrows, etc. — return 0 */
};

static const char scancode_shift[128] = {
    0,    27,  '!', '@', '#', '$', '%', '^', '&', '*', '(', ')', '_',  '+',
    '\b', '\t','Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P', '{',  '}',
    '\n', 0,   'A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L', ':', '"',  '~',
    0,    '|', 'Z', 'X', 'C', 'V', 'B', 'N', 'M', '<', '>', '?', 0,    '*',
    0,    ' ',
};

/* ── Ring buffer ─────────────────────────────────────────────────────── */
#define KBD_BUFSIZE 64
static volatile char kbd_buf[KBD_BUFSIZE];
static volatile int  kbd_head = 0;
static volatile int  kbd_tail = 0;

static bool shift_held  = false;
static bool caps_lock   = false;

static void buf_push(char c) {
    int next = (kbd_head + 1) % KBD_BUFSIZE;
    if (next != kbd_tail) {
        kbd_buf[kbd_head] = c;
        kbd_head = next;
    }
}

/* ── IRQ1 handler ────────────────────────────────────────────────────── */
static void kbd_irq(void) {
    uint8_t sc = inb(KBD_DATA);
    bool released = (sc & 0x80) != 0;
    uint8_t key   = sc & 0x7F;

    /* Track modifier keys */
    if (key == 0x2A || key == 0x36) { shift_held = !released; return; }
    if (key == 0x3A && !released)   { caps_lock  = !caps_lock; return; }
    if (released) return;

    char c = 0;
    if (key < 128) {
        if (shift_held) {
            c = scancode_shift[key];
        } else {
            c = scancode_table[key];
            if (caps_lock && c >= 'a' && c <= 'z') c -= 32;
        }
    }
    if (c) buf_push(c);
}

/* ── Public API ──────────────────────────────────────────────────────── */
void keyboard_init(void) {
    /* Flush any pending data in the controller buffer */
    while (inb(KBD_STATUS) & 0x01) inb(KBD_DATA);
    /* Register IRQ1 handler */
    extern void irq_register(uint8_t irq, void (*handler)(void));
    irq_register(1, kbd_irq);
    /* Enable keyboard IRQ in PIC (unmask IRQ1) */
    uint8_t mask = inb(0x21);
    outb(0x21, mask & ~0x02);
}

bool keyboard_has_char(void) {
    return kbd_head != kbd_tail;
}

char keyboard_getchar(void) {
    while (!keyboard_has_char()) hlt();
    char c = kbd_buf[kbd_tail];
    kbd_tail = (kbd_tail + 1) % KBD_BUFSIZE;
    return c;
}
