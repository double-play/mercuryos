#pragma once
#include <stdint.h>
#include <stdbool.h>

/* ─── Mercury OS ─ kernel/drivers/keyboard.h ─────────────────────────── */

void keyboard_init(void);
bool keyboard_has_char(void);
char keyboard_getchar(void);    /* blocks until a char is available */
