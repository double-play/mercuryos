#pragma once
#include <stdint.h>

/* ─── Mercury OS ─ kernel/drivers/timer.h ────────────────────────────── */

#define TIMER_HZ    1000   /* 1 ms tick */

void     timer_init(void);
uint64_t timer_ticks(void);
void     timer_sleep(uint64_t ms);
