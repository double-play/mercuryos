/* ─── Mercury OS ─ kernel/drivers/vga.c ──────────────────────────────── */

#include "vga.h"
#include <stdint.h>
#include <stddef.h>

#define VGA_BUFFER   ((volatile uint16_t *)0xB8000)
#define VGA_CMD      0x3D4
#define VGA_DATA     0x3D5

/* ── Internal state ─────────────────────────────────────────────────── */
static int     cursor_x = 0;
static int     cursor_y = 0;
static uint8_t current_color;

static inline uint8_t make_color(vga_color_t fg, vga_color_t bg) {
    return (uint8_t)((bg << 4) | (fg & 0x0F));
}
static inline uint16_t make_entry(char c, uint8_t color) {
    return (uint16_t)((uint16_t)color << 8) | (uint8_t)c;
}

/* ── Hardware cursor ─────────────────────────────────────────────────── */
static void update_hw_cursor(void) {
    uint16_t pos = (uint16_t)(cursor_y * VGA_WIDTH + cursor_x);
    /* Write to CRT controller registers 14 (high) and 15 (low) */
    __asm__ volatile ("outb %0, %1" : : "a"((uint8_t)14),  "Nd"((uint16_t)VGA_CMD));
    __asm__ volatile ("outb %0, %1" : : "a"((uint8_t)(pos >> 8)),   "Nd"((uint16_t)VGA_DATA));
    __asm__ volatile ("outb %0, %1" : : "a"((uint8_t)15),  "Nd"((uint16_t)VGA_CMD));
    __asm__ volatile ("outb %0, %1" : : "a"((uint8_t)(pos & 0xFF)), "Nd"((uint16_t)VGA_DATA));
}

/* ── Public API ──────────────────────────────────────────────────────── */
void vga_init(void) {
    current_color = make_color(VGA_LIGHT_GREY, VGA_BLACK);
    vga_clear();
}

void vga_clear(void) {
    for (int y = 0; y < VGA_HEIGHT; y++)
        for (int x = 0; x < VGA_WIDTH; x++)
            VGA_BUFFER[y * VGA_WIDTH + x] = make_entry(' ', current_color);
    cursor_x = 0;
    cursor_y = 0;
    update_hw_cursor();
}

void vga_set_color(vga_color_t fg, vga_color_t bg) {
    current_color = make_color(fg, bg);
}

void vga_scroll(void) {
    /* Move every row up by one */
    for (int y = 0; y < VGA_HEIGHT - 1; y++)
        for (int x = 0; x < VGA_WIDTH; x++)
            VGA_BUFFER[y * VGA_WIDTH + x] = VGA_BUFFER[(y + 1) * VGA_WIDTH + x];
    /* Clear the last row */
    for (int x = 0; x < VGA_WIDTH; x++)
        VGA_BUFFER[(VGA_HEIGHT - 1) * VGA_WIDTH + x] = make_entry(' ', current_color);
}

void vga_set_cursor(int x, int y) {
    cursor_x = x;
    cursor_y = y;
    update_hw_cursor();
}

void vga_putchar(char c) {
    if (c == '\n') {
        cursor_x = 0;
        cursor_y++;
    } else if (c == '\r') {
        cursor_x = 0;
    } else if (c == '\t') {
        cursor_x = (cursor_x + 8) & ~7;
    } else if (c == '\b') {
        if (cursor_x > 0) cursor_x--;
    } else {
        VGA_BUFFER[cursor_y * VGA_WIDTH + cursor_x] = make_entry(c, current_color);
        cursor_x++;
    }

    if (cursor_x >= VGA_WIDTH) {
        cursor_x = 0;
        cursor_y++;
    }
    if (cursor_y >= VGA_HEIGHT) {
        vga_scroll();
        cursor_y = VGA_HEIGHT - 1;
    }
    update_hw_cursor();
}

void vga_puts(const char *str) {
    for (; *str; str++)
        vga_putchar(*str);
}
