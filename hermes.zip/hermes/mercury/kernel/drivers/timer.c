/* ─── Mercury OS ─ kernel/drivers/timer.c ────────────────────────────── */

#include "timer.h"
#include "../mercury.h"
#include "../cpu/idt.h"

/* PIT I/O ports */
#define PIT_CH0     0x40
#define PIT_CMD     0x43
/* Mode: channel 0, lo/hi byte, mode 3 (square wave), binary */
#define PIT_MODE    0x36

#define PIT_BASE_HZ 1193182UL

static volatile uint64_t tick_count = 0;

static void timer_irq(void) {
    tick_count++;
}

void timer_init(void) {
    /* Calculate reload value for desired frequency */
    uint32_t divisor = (uint32_t)(PIT_BASE_HZ / TIMER_HZ);

    outb(PIT_CMD, PIT_MODE);
    outb(PIT_CH0, (uint8_t)(divisor & 0xFF));
    outb(PIT_CH0, (uint8_t)((divisor >> 8) & 0xFF));

    /* Register IRQ0 */
    extern void irq_register(uint8_t irq, void (*handler)(void));
    irq_register(0, timer_irq);

    /* Unmask IRQ0 in PIC */
    uint8_t mask = inb(0x21);
    outb(0x21, mask & ~0x01);
}

uint64_t timer_ticks(void) {
    return tick_count;
}

void timer_sleep(uint64_t ms) {
    uint64_t end = tick_count + ms;
    while (tick_count < end) hlt();
}
