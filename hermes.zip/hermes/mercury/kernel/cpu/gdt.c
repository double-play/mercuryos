/* ─── Mercury OS ─ kernel/cpu/gdt.c ──────────────────────────────────── */
/*
 * Sets up a minimal 64-bit GDT:
 *   0x00  null descriptor
 *   0x08  kernel code  (64-bit, ring 0)
 *   0x10  kernel data  (ring 0)
 *   0x18  user code    (64-bit, ring 3)
 *   0x20  user data    (ring 3)
 */

#include "gdt.h"
#include "../mercury.h"

/* ── Descriptor structures ───────────────────────────────────────────── */
typedef struct {
    uint16_t limit_low;
    uint16_t base_low;
    uint8_t  base_mid;
    uint8_t  access;
    uint8_t  gran;       /* flags[7:4] | limit_high[3:0] */
    uint8_t  base_high;
} PACKED gdt_entry_t;

typedef struct {
    uint16_t limit;
    uint64_t base;
} PACKED gdtr_t;

/* ── Access byte flags ───────────────────────────────────────────────── */
#define GDT_PRESENT     (1 << 7)
#define GDT_RING0       (0 << 5)
#define GDT_RING3       (3 << 5)
#define GDT_CODE_DATA   (1 << 4)
#define GDT_CODE_SEG    (1 << 3)
#define GDT_READABLE    (1 << 1)
#define GDT_WRITABLE    (1 << 1)

/* Granularity byte */
#define GDT_LONG_MODE   (1 << 5)
#define GDT_4K_GRAN     (1 << 7)

#define GDT_KCODE_ACCESS (GDT_PRESENT | GDT_RING0 | GDT_CODE_DATA | GDT_CODE_SEG | GDT_READABLE)
#define GDT_KDATA_ACCESS (GDT_PRESENT | GDT_RING0 | GDT_CODE_DATA | GDT_WRITABLE)
#define GDT_UCODE_ACCESS (GDT_PRESENT | GDT_RING3 | GDT_CODE_DATA | GDT_CODE_SEG | GDT_READABLE)
#define GDT_UDATA_ACCESS (GDT_PRESENT | GDT_RING3 | GDT_CODE_DATA | GDT_WRITABLE)

/* ── GDT table ───────────────────────────────────────────────────────── */
static gdt_entry_t gdt[5] ALIGNED(16);
static gdtr_t      gdtr;

static void gdt_set(int idx, uint32_t base, uint32_t limit, uint8_t access, uint8_t gran) {
    gdt[idx].limit_low = (uint16_t)(limit & 0xFFFF);
    gdt[idx].base_low  = (uint16_t)(base  & 0xFFFF);
    gdt[idx].base_mid  = (uint8_t)((base  >> 16) & 0xFF);
    gdt[idx].access    = access;
    gdt[idx].gran      = (uint8_t)((gran & 0xF0) | ((limit >> 16) & 0x0F));
    gdt[idx].base_high = (uint8_t)((base  >> 24) & 0xFF);
}

/* Defined in gdt_flush.asm */
extern void gdt_flush(uint64_t gdtr_ptr);

void gdt_init(void) {
    gdt_set(0, 0, 0,          0,                           0);
    gdt_set(1, 0, 0xFFFFF,    GDT_KCODE_ACCESS,            GDT_4K_GRAN | GDT_LONG_MODE);
    gdt_set(2, 0, 0xFFFFF,    GDT_KDATA_ACCESS,            GDT_4K_GRAN | GDT_LONG_MODE);
    gdt_set(3, 0, 0xFFFFF,    GDT_UCODE_ACCESS,            GDT_4K_GRAN | GDT_LONG_MODE);
    gdt_set(4, 0, 0xFFFFF,    GDT_UDATA_ACCESS,            GDT_4K_GRAN | GDT_LONG_MODE);

    gdtr.limit = (uint16_t)(sizeof(gdt) - 1);
    gdtr.base  = (uint64_t)&gdt;

    gdt_flush((uint64_t)&gdtr);
}
