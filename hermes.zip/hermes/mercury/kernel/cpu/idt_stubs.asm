; ─── Mercury OS ─ kernel/cpu/idt_stubs.asm ──────────────────────────────
; Generates ISR and IRQ entry stubs.
; Each stub pushes a fake (or real) error code + int number, then calls the
; common handler which constructs interrupt_frame_t on the stack.

section .text

; ── C handlers ────────────────────────────────────────────────────────
extern exception_handler
extern irq_handler

; ── Common save/restore macro ─────────────────────────────────────────
; After CPU pushes  ss, rsp, rflags, cs, rip  (+ optional err_code)
; our stub adds:    int_no, err_code
; then we push all GP registers to match interrupt_frame_t.

%macro SAVE_REGS 0
    push rax
    push rbx
    push rcx
    push rdx
    push rsi
    push rdi
    push rbp
    push r8
    push r9
    push r10
    push r11
    push r12
    push r13
    push r14
    push r15
%endmacro

%macro RESTORE_REGS 0
    pop r15
    pop r14
    pop r13
    pop r12
    pop r11
    pop r10
    pop r9
    pop r8
    pop rbp
    pop rdi
    pop rsi
    pop rdx
    pop rcx
    pop rbx
    pop rax
%endmacro

; ── Exception stubs ────────────────────────────────────────────────────
; Exceptions WITHOUT error code: push 0 as dummy
%macro ISR_NOERR 1
global isr%1
isr%1:
    push qword 0        ; dummy error code
    push qword %1       ; interrupt number
    jmp isr_common
%endmacro

; Exceptions WITH error code: CPU already pushed it
%macro ISR_ERR 1
global isr%1
isr%1:
    push qword %1
    jmp isr_common
%endmacro

ISR_NOERR  0
ISR_NOERR  1
ISR_NOERR  2
ISR_NOERR  3
ISR_NOERR  4
ISR_NOERR  5
ISR_NOERR  6
ISR_NOERR  7
ISR_ERR    8          ; double fault  (has error code)
ISR_NOERR  9
ISR_ERR   10          ; invalid TSS
ISR_ERR   11          ; segment not present
ISR_ERR   12          ; stack fault
ISR_ERR   13          ; general protection
ISR_ERR   14          ; page fault
ISR_NOERR 15
ISR_NOERR 16
ISR_ERR   17          ; alignment check
ISR_NOERR 18
ISR_NOERR 19

isr_common:
    SAVE_REGS
    mov rdi, rsp        ; first arg = pointer to interrupt_frame_t
    call exception_handler
    RESTORE_REGS
    add rsp, 16         ; pop int_no + err_code
    iretq

; ── IRQ stubs ──────────────────────────────────────────────────────────
%macro IRQ_STUB 1
global irq%1
irq%1:
    push qword 0
    push qword (0x20 + %1)
    jmp irq_common
%endmacro

IRQ_STUB  0   ; PIT timer
IRQ_STUB  1   ; keyboard
IRQ_STUB  2
IRQ_STUB  3
IRQ_STUB  4
IRQ_STUB  5
IRQ_STUB  6
IRQ_STUB  7
IRQ_STUB  8
IRQ_STUB  9
IRQ_STUB 10
IRQ_STUB 11
IRQ_STUB 12
IRQ_STUB 13
IRQ_STUB 14
IRQ_STUB 15

irq_common:
    SAVE_REGS
    mov rdi, rsp
    call irq_handler
    RESTORE_REGS
    add rsp, 16
    iretq
