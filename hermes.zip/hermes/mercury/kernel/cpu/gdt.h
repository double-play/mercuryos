#pragma once
#include <stdint.h>

/* ─── Mercury OS ─ kernel/cpu/gdt.h ──────────────────────────────────── */

void gdt_init(void);
