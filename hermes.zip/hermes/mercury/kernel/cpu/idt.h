#pragma once
#include <stdint.h>

/* ─── Mercury OS ─ kernel/cpu/idt.h ──────────────────────────────────── */

/* CPU exception vectors */
#define INT_DIVIDE_ERROR     0
#define INT_DEBUG            1
#define INT_NMI              2
#define INT_BREAKPOINT       3
#define INT_OVERFLOW         4
#define INT_BOUND_RANGE      5
#define INT_INVALID_OPCODE   6
#define INT_DEVICE_NA        7
#define INT_DOUBLE_FAULT     8
#define INT_INVALID_TSS      10
#define INT_SEGMENT_NP       11
#define INT_STACK_FAULT      12
#define INT_GP_FAULT         13
#define INT_PAGE_FAULT       14
#define INT_FPU_ERROR        16
#define INT_ALIGNMENT_CHECK  17
#define INT_MACHINE_CHECK    18
#define INT_SIMD_FP          19

/* IRQ vectors (after PIC remapping to 0x20–0x2F) */
#define IRQ_BASE    0x20
#define IRQ_TIMER   (IRQ_BASE + 0)
#define IRQ_KBD     (IRQ_BASE + 1)

/* Saved register state pushed by our stubs */
typedef struct {
    uint64_t r15, r14, r13, r12, r11, r10, r9, r8;
    uint64_t rbp, rdi, rsi, rdx, rcx, rbx, rax;
    uint64_t int_no, err_code;
    /* CPU-pushed on interrupt entry */
    uint64_t rip, cs, rflags, rsp, ss;
} PACKED interrupt_frame_t;

void idt_init(void);
void idt_set_handler(uint8_t vec, void (*handler)(void), uint8_t flags);
