; ─── Mercury OS ─ kernel/cpu/gdt_flush.asm ───────────────────────────
; Loads the new GDTR and performs a far jump to reload CS.
; Called from C as: void gdt_flush(uint64_t gdtr_ptr)
;   rdi = pointer to gdtr structure

section .text
global gdt_flush

gdt_flush:
    lgdt [rdi]          ; Load new GDT
    ; Reload data segment registers with kernel data selector (0x10)
    mov ax, 0x10
    mov ds, ax
    mov es, ax
    mov fs, ax
    mov gs, ax
    mov ss, ax
    ; Far return to reload CS with kernel code selector (0x08).
    ; Push segment then return address, then retfq.
    pop rdi             ; Save return address
    push 0x08           ; New CS
    push rdi            ; Return address
    retfq
