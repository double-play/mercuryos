/* ─── Mercury OS ─ kernel/cpu/idt.c ──────────────────────────────────── */

#include "idt.h"
#include "../mercury.h"

/* ── Gate descriptor ─────────────────────────────────────────────────── */
typedef struct {
    uint16_t offset_low;
    uint16_t selector;      /* kernel code segment */
    uint8_t  ist;           /* Interrupt Stack Table index (0 = none) */
    uint8_t  type_attr;
    uint16_t offset_mid;
    uint32_t offset_high;
    uint32_t zero;
} PACKED idt_entry_t;

typedef struct {
    uint16_t limit;
    uint64_t base;
} PACKED idtr_t;

/* ── Flags ───────────────────────────────────────────────────────────── */
#define IDT_INT_GATE   0x8E  /* Present | Ring0 | Interrupt Gate (64-bit) */
#define IDT_TRAP_GATE  0x8F  /* Present | Ring0 | Trap Gate (64-bit) */

/* ── IDT storage ─────────────────────────────────────────────────────── */
#define IDT_ENTRIES 256
static idt_entry_t idt[IDT_ENTRIES] ALIGNED(16);
static idtr_t      idtr;

/* ── ISR stubs declared in idt_stubs.asm ───────────────────────────── */
/* CPU exceptions (0–19) */
extern void isr0(void);  extern void isr1(void);  extern void isr2(void);
extern void isr3(void);  extern void isr4(void);  extern void isr5(void);
extern void isr6(void);  extern void isr7(void);  extern void isr8(void);
extern void isr9(void);  extern void isr10(void); extern void isr11(void);
extern void isr12(void); extern void isr13(void); extern void isr14(void);
extern void isr15(void); extern void isr16(void); extern void isr17(void);
extern void isr18(void); extern void isr19(void);
/* IRQ stubs (0x20–0x2F) */
extern void irq0(void);  extern void irq1(void);  extern void irq2(void);
extern void irq3(void);  extern void irq4(void);  extern void irq5(void);
extern void irq6(void);  extern void irq7(void);  extern void irq8(void);
extern void irq9(void);  extern void irq10(void); extern void irq11(void);
extern void irq12(void); extern void irq13(void); extern void irq14(void);
extern void irq15(void);

/* ── Gate helpers ────────────────────────────────────────────────────── */
void idt_set_handler(uint8_t vec, void (*handler)(void), uint8_t flags) {
    uintptr_t addr = (uintptr_t)handler;
    idt[vec].offset_low  = (uint16_t)(addr & 0xFFFF);
    idt[vec].selector    = 0x08;   /* kernel code segment */
    idt[vec].ist         = 0;
    idt[vec].type_attr   = flags;
    idt[vec].offset_mid  = (uint16_t)((addr >> 16) & 0xFFFF);
    idt[vec].offset_high = (uint32_t)((addr >> 32) & 0xFFFFFFFF);
    idt[vec].zero        = 0;
}

/* ── C-level handlers (called from assembly stubs) ───────────────────── */

/* Exception names for pretty printing */
static const char *exception_names[] = {
    "Divide Error",        "Debug",                "NMI",
    "Breakpoint",          "Overflow",             "Bound Range Exceeded",
    "Invalid Opcode",      "Device Not Available",  "Double Fault",
    "Coprocessor Segment", "Invalid TSS",           "Segment Not Present",
    "Stack-Segment Fault", "General Protection",    "Page Fault",
    "Reserved",            "x87 FP Exception",      "Alignment Check",
    "Machine Check",       "SIMD FP Exception",
};

/* IRQ handler table — registered externally */
static void (*irq_handlers[16])(void) = { 0 };

void irq_register(uint8_t irq, void (*handler)(void)) {
    irq_handlers[irq] = handler;
}

/* Called by every exception stub */
void exception_handler(interrupt_frame_t *frame) {
    const char *name = (frame->int_no < 20)
                       ? exception_names[frame->int_no]
                       : "Unknown";
    PANIC("Exception #%llu (%s)  err=%llx  rip=%p  rsp=%p",
          frame->int_no, name, frame->err_code,
          (void *)frame->rip, (void *)frame->rsp);
}

/* Called by every IRQ stub */
void irq_handler(interrupt_frame_t *frame) {
    uint8_t irq = (uint8_t)(frame->int_no - IRQ_BASE);

    if (irq_handlers[irq])
        irq_handlers[irq]();

    /* Send EOI to PIC */
    if (irq >= 8) outb(0xA0, 0x20);   /* secondary PIC */
    outb(0x20, 0x20);                  /* primary PIC */
}

/* ── PIC remapping ───────────────────────────────────────────────────── */
static void pic_remap(void) {
    /* Save masks */
    uint8_t m1 = inb(0x21), m2 = inb(0xA1);

    /* ICW1: begin initialization */
    outb(0x20, 0x11); io_wait();
    outb(0xA0, 0x11); io_wait();
    /* ICW2: vector offsets */
    outb(0x21, 0x20); io_wait();   /* IRQ 0–7  → INT 0x20–0x27 */
    outb(0xA1, 0x28); io_wait();   /* IRQ 8–15 → INT 0x28–0x2F */
    /* ICW3: cascading */
    outb(0x21, 0x04); io_wait();
    outb(0xA1, 0x02); io_wait();
    /* ICW4: 8086 mode */
    outb(0x21, 0x01); io_wait();
    outb(0xA1, 0x01); io_wait();
    /* Restore masks */
    outb(0x21, m1);
    outb(0xA1, m2);
}

/* ── Public init ─────────────────────────────────────────────────────── */
void idt_init(void) {
    /* Remap PIC before installing IRQ handlers */
    pic_remap();

    /* CPU exceptions */
    idt_set_handler(0,  isr0,  IDT_INT_GATE);
    idt_set_handler(1,  isr1,  IDT_TRAP_GATE);
    idt_set_handler(2,  isr2,  IDT_INT_GATE);
    idt_set_handler(3,  isr3,  IDT_TRAP_GATE);
    idt_set_handler(4,  isr4,  IDT_TRAP_GATE);
    idt_set_handler(5,  isr5,  IDT_INT_GATE);
    idt_set_handler(6,  isr6,  IDT_INT_GATE);
    idt_set_handler(7,  isr7,  IDT_INT_GATE);
    idt_set_handler(8,  isr8,  IDT_INT_GATE);
    idt_set_handler(9,  isr9,  IDT_INT_GATE);
    idt_set_handler(10, isr10, IDT_INT_GATE);
    idt_set_handler(11, isr11, IDT_INT_GATE);
    idt_set_handler(12, isr12, IDT_INT_GATE);
    idt_set_handler(13, isr13, IDT_INT_GATE);
    idt_set_handler(14, isr14, IDT_INT_GATE);
    idt_set_handler(15, isr15, IDT_INT_GATE);
    idt_set_handler(16, isr16, IDT_INT_GATE);
    idt_set_handler(17, isr17, IDT_INT_GATE);
    idt_set_handler(18, isr18, IDT_INT_GATE);
    idt_set_handler(19, isr19, IDT_INT_GATE);

    /* Hardware IRQs */
    idt_set_handler(IRQ_BASE + 0,  irq0,  IDT_INT_GATE);
    idt_set_handler(IRQ_BASE + 1,  irq1,  IDT_INT_GATE);
    idt_set_handler(IRQ_BASE + 2,  irq2,  IDT_INT_GATE);
    idt_set_handler(IRQ_BASE + 3,  irq3,  IDT_INT_GATE);
    idt_set_handler(IRQ_BASE + 4,  irq4,  IDT_INT_GATE);
    idt_set_handler(IRQ_BASE + 5,  irq5,  IDT_INT_GATE);
    idt_set_handler(IRQ_BASE + 6,  irq6,  IDT_INT_GATE);
    idt_set_handler(IRQ_BASE + 7,  irq7,  IDT_INT_GATE);
    idt_set_handler(IRQ_BASE + 8,  irq8,  IDT_INT_GATE);
    idt_set_handler(IRQ_BASE + 9,  irq9,  IDT_INT_GATE);
    idt_set_handler(IRQ_BASE + 10, irq10, IDT_INT_GATE);
    idt_set_handler(IRQ_BASE + 11, irq11, IDT_INT_GATE);
    idt_set_handler(IRQ_BASE + 12, irq12, IDT_INT_GATE);
    idt_set_handler(IRQ_BASE + 13, irq13, IDT_INT_GATE);
    idt_set_handler(IRQ_BASE + 14, irq14, IDT_INT_GATE);
    idt_set_handler(IRQ_BASE + 15, irq15, IDT_INT_GATE);

    idtr.limit = (uint16_t)(sizeof(idt) - 1);
    idtr.base  = (uint64_t)&idt;
    __asm__ volatile ("lidt [%0]" : : "m"(idtr));
}
