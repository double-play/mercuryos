#pragma once

/* ─── Mercury OS ─ kernel/mercury.h ──────────────────────────────────────
   Core types, macros, and forward declarations used everywhere.
   ───────────────────────────────────────────────────────────────────────── */

#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdarg.h>

/* ── Compiler helpers ────────────────────────────────────────────────── */
#define PACKED          __attribute__((packed))
#define NORETURN        __attribute__((noreturn))
#define ALIGNED(n)      __attribute__((aligned(n)))
#define ALWAYS_INLINE   __attribute__((always_inline)) inline
#define UNUSED          __attribute__((unused))

/* ── Sizes / alignment ───────────────────────────────────────────────── */
#define KiB             (1024ULL)
#define MiB             (1024ULL * KiB)
#define GiB             (1024ULL * MiB)
#define PAGE_SIZE       (4096ULL)
#define PAGE_ALIGN(x)   (((uintptr_t)(x) + PAGE_SIZE - 1) & ~(PAGE_SIZE - 1))
#define PAGE_ALIGN_DOWN(x) ((uintptr_t)(x) & ~(PAGE_SIZE - 1))

/* ── Kernel virtual base (higher-half) ──────────────────────────────── */
#define KERNEL_VIRT_BASE    0xFFFFFFFF80000000ULL
#define PHYS_TO_VIRT(p)     ((void *)((uintptr_t)(p) + KERNEL_VIRT_BASE))
#define VIRT_TO_PHYS(v)     ((uintptr_t)(v) - KERNEL_VIRT_BASE)

/* ── Panic ───────────────────────────────────────────────────────────── */
NORETURN void kpanic(const char *file, int line, const char *fmt, ...);
#define PANIC(fmt, ...) kpanic(__FILE__, __LINE__, fmt, ##__VA_ARGS__)
#define ASSERT(cond) do { if (!(cond)) PANIC("Assertion failed: " #cond); } while(0)

/* ── Logging ─────────────────────────────────────────────────────────── */
void kprintf(const char *fmt, ...);
void kvprintf(const char *fmt, va_list ap);

/* ── Port I/O ────────────────────────────────────────────────────────── */
static ALWAYS_INLINE void outb(uint16_t port, uint8_t val) {
    __asm__ volatile ("outb %0, %1" : : "a"(val), "Nd"(port) : "memory");
}
static ALWAYS_INLINE uint8_t inb(uint16_t port) {
    uint8_t ret;
    __asm__ volatile ("inb %1, %0" : "=a"(ret) : "Nd"(port) : "memory");
    return ret;
}
static ALWAYS_INLINE void outw(uint16_t port, uint16_t val) {
    __asm__ volatile ("outw %0, %1" : : "a"(val), "Nd"(port) : "memory");
}
static ALWAYS_INLINE uint16_t inw(uint16_t port) {
    uint16_t ret;
    __asm__ volatile ("inw %1, %0" : "=a"(ret) : "Nd"(port) : "memory");
    return ret;
}
static ALWAYS_INLINE void io_wait(void) { outb(0x80, 0); }

/* ── Interrupt control ───────────────────────────────────────────────── */
static ALWAYS_INLINE void cli(void) { __asm__ volatile ("cli" ::: "memory"); }
static ALWAYS_INLINE void sti(void) { __asm__ volatile ("sti" ::: "memory"); }
static ALWAYS_INLINE void hlt(void) { __asm__ volatile ("hlt" ::: "memory"); }
