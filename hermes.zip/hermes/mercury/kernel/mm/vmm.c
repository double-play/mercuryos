/* ─── Mercury OS ─ kernel/mm/vmm.c ───────────────────────────────────── */
/*
 * 4-level (PML4 → PDPT → PD → PT) page table management.
 * Kernel lives at -2 GiB (0xFFFFFFFF80000000) in all address spaces.
 */

#include "vmm.h"
#include "pmm.h"
#include "../mercury.h"

#define ENTRIES_PER_TABLE   512
#define PML4_IDX(v)  (((v) >> 39) & 0x1FF)
#define PDPT_IDX(v)  (((v) >> 30) & 0x1FF)
#define PD_IDX(v)    (((v) >> 21) & 0x1FF)
#define PT_IDX(v)    (((v) >> 12) & 0x1FF)
#define ADDR_MASK    (~0xFFFULL & ~VMM_NX)

/* ── Helpers ─────────────────────────────────────────────────────────── */

/* Allocate a zeroed physical page for a new table and return its virt addr */
static uint64_t *new_table(void) {
    void *phys = pmm_alloc();
    uint64_t *tbl = (uint64_t *)PHYS_TO_VIRT(phys);
    for (int i = 0; i < ENTRIES_PER_TABLE; i++) tbl[i] = 0;
    return tbl;
}

/* Get or create the next-level table pointer */
static uint64_t *ensure_table(uint64_t *parent, size_t idx, uint64_t flags) {
    if (!(parent[idx] & VMM_PRESENT)) {
        void *phys = new_table();
        parent[idx] = (uint64_t)VIRT_TO_PHYS(phys) | flags | VMM_PRESENT;
    }
    return (uint64_t *)PHYS_TO_VIRT(parent[idx] & ADDR_MASK);
}

/* ── Public API ──────────────────────────────────────────────────────── */

void vmm_map(page_table_t pml4, uintptr_t virt, uintptr_t phys, uint64_t flags) {
    uint64_t *pdpt = ensure_table(pml4, PML4_IDX(virt), VMM_WRITABLE | VMM_PRESENT);
    uint64_t *pd   = ensure_table(pdpt, PDPT_IDX(virt), VMM_WRITABLE | VMM_PRESENT);
    uint64_t *pt   = ensure_table(pd,   PD_IDX(virt),   VMM_WRITABLE | VMM_PRESENT);

    pt[PT_IDX(virt)] = (phys & ~0xFFFULL) | flags | VMM_PRESENT;

    /* TLB shootdown for this address */
    __asm__ volatile ("invlpg [%0]" : : "r"(virt) : "memory");
}

void vmm_unmap(page_table_t pml4, uintptr_t virt) {
    uint64_t *pdpt, *pd, *pt;
    if (!(pml4[PML4_IDX(virt)] & VMM_PRESENT)) return;
    pdpt = (uint64_t *)PHYS_TO_VIRT(pml4[PML4_IDX(virt)] & ADDR_MASK);
    if (!(pdpt[PDPT_IDX(virt)] & VMM_PRESENT)) return;
    pd = (uint64_t *)PHYS_TO_VIRT(pdpt[PDPT_IDX(virt)] & ADDR_MASK);
    if (!(pd[PD_IDX(virt)] & VMM_PRESENT)) return;
    pt = (uint64_t *)PHYS_TO_VIRT(pd[PD_IDX(virt)] & ADDR_MASK);
    pt[PT_IDX(virt)] = 0;
    __asm__ volatile ("invlpg [%0]" : : "r"(virt) : "memory");
}

void vmm_switch(page_table_t pml4) {
    uintptr_t phys = VIRT_TO_PHYS((uintptr_t)pml4);
    __asm__ volatile ("mov cr3, %0" : : "r"(phys) : "memory");
}

/* Kernel PML4 (set up during vmm_init, shared into all spaces) */
static page_table_t kernel_pml4 = NULL;

void vmm_init(void) {
    /* Allocate a fresh PML4 for the kernel */
    kernel_pml4 = new_table();

    /* Identity-map and higher-half-map the first 4 GiB for now.
       Real OS would walk the PMM's memory map here instead.      */
    for (uintptr_t phys = 0; phys < 4ULL * GiB; phys += PAGE_SIZE) {
        /* Identity map */
        vmm_map(kernel_pml4, phys, phys, VMM_WRITABLE);
        /* Higher-half map at KERNEL_VIRT_BASE */
        vmm_map(kernel_pml4, KERNEL_VIRT_BASE + phys, phys, VMM_WRITABLE);
    }

    vmm_switch(kernel_pml4);
}

page_table_t vmm_new_space(void) {
    page_table_t pml4 = new_table();
    /* Copy kernel half (top 256 PML4 entries) so kernel is reachable
       from every address space without separate mappings. */
    for (int i = 256; i < 512; i++)
        pml4[i] = kernel_pml4[i];
    return pml4;
}
