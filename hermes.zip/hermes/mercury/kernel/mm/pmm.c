/* ─── Mercury OS ─ kernel/mm/pmm.c ───────────────────────────────────── */

#include "pmm.h"
#include "../mercury.h"

/* ── Bitmap helpers ──────────────────────────────────────────────────── */
#define BITS_PER_WORD   64
typedef uint64_t word_t;

static word_t  *bitmap      = NULL;
static size_t   total_frames = 0;
static size_t   free_count   = 0;
static size_t   bitmap_words = 0;

static inline void bitmap_set(size_t frame) {
    bitmap[frame / BITS_PER_WORD] |= (1ULL << (frame % BITS_PER_WORD));
}
static inline void bitmap_clear(size_t frame) {
    bitmap[frame / BITS_PER_WORD] &= ~(1ULL << (frame % BITS_PER_WORD));
}
static inline bool bitmap_test(size_t frame) {
    return (bitmap[frame / BITS_PER_WORD] >> (frame % BITS_PER_WORD)) & 1;
}

/* ── Init ────────────────────────────────────────────────────────────── */
void pmm_init(pmm_mmap_entry_t *entries, size_t count, uint64_t mem_top) {
    total_frames = mem_top / PAGE_SIZE;
    bitmap_words = (total_frames + BITS_PER_WORD - 1) / BITS_PER_WORD;
    size_t bitmap_bytes = bitmap_words * sizeof(word_t);

    /*
     * Find a suitable place for the bitmap: first usable region large enough.
     * We place it at the physical address right after the kernel.
     */
    extern char _kernel_end[];
    uintptr_t bitmap_phys = VIRT_TO_PHYS((uintptr_t)_kernel_end);
    bitmap_phys = PAGE_ALIGN(bitmap_phys);

    bitmap = (word_t *)PHYS_TO_VIRT(bitmap_phys);

    /* Start with everything marked used */
    for (size_t i = 0; i < bitmap_words; i++) bitmap[i] = ~0ULL;
    free_count = 0;

    /* Mark usable regions as free */
    for (size_t i = 0; i < count; i++) {
        if (entries[i].type != 1) continue;       /* only type=1 is usable */
        uint64_t base = PAGE_ALIGN(entries[i].base);
        uint64_t end  = PAGE_ALIGN_DOWN(entries[i].base + entries[i].length);
        for (uint64_t addr = base; addr < end; addr += PAGE_SIZE) {
            size_t frame = addr / PAGE_SIZE;
            if (frame < total_frames) {
                bitmap_clear(frame);
                free_count++;
            }
        }
    }

    /* Re-mark the bitmap storage itself as used */
    size_t bmap_frames = (bitmap_bytes + PAGE_SIZE - 1) / PAGE_SIZE;
    for (size_t i = 0; i < bmap_frames; i++) {
        size_t frame = (bitmap_phys / PAGE_SIZE) + i;
        if (!bitmap_test(frame)) { bitmap_set(frame); free_count--; }
    }

    /* Mark first physical page as used (real-mode IVT / BIOS area) */
    if (!bitmap_test(0)) { bitmap_set(0); free_count--; }
}

/* ── Allocate one frame ──────────────────────────────────────────────── */
void *pmm_alloc(void) {
    for (size_t w = 0; w < bitmap_words; w++) {
        if (bitmap[w] == ~0ULL) continue;       /* all used, skip */
        int bit = __builtin_ctzll(~bitmap[w]);  /* first free bit */
        size_t frame = w * BITS_PER_WORD + (size_t)bit;
        if (frame >= total_frames) break;
        bitmap_set(frame);
        free_count--;
        return (void *)(frame * PAGE_SIZE);
    }
    PANIC("PMM: out of physical memory");
}

/* ── Allocate n contiguous frames ────────────────────────────────────── */
void *pmm_alloc_n(size_t n) {
    size_t run = 0, start = 0;
    for (size_t frame = 0; frame < total_frames; frame++) {
        if (!bitmap_test(frame)) {
            if (run == 0) start = frame;
            if (++run == n) {
                for (size_t i = 0; i < n; i++) { bitmap_set(start + i); free_count--; }
                return (void *)(start * PAGE_SIZE);
            }
        } else {
            run = 0;
        }
    }
    PANIC("PMM: cannot allocate %zu contiguous frames", n);
}

/* ── Free ────────────────────────────────────────────────────────────── */
void pmm_free(void *addr) {
    size_t frame = (uintptr_t)addr / PAGE_SIZE;
    ASSERT(!bitmap_test(frame));   /* double-free detection */
    bitmap_clear(frame);
    free_count++;
}

void pmm_free_n(void *addr, size_t n) {
    for (size_t i = 0; i < n; i++)
        pmm_free((void *)((uintptr_t)addr + i * PAGE_SIZE));
}

size_t pmm_free_frames(void)  { return free_count; }
size_t pmm_total_frames(void) { return total_frames; }
