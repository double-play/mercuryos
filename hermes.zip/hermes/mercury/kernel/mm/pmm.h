#pragma once
#include <stdint.h>
#include <stddef.h>

/* ─── Mercury OS ─ kernel/mm/pmm.h ───────────────────────────────────── */

/*
 * Mercury Physical Memory Manager
 * ─────────────────────────────────
 * Bitmap-based allocator.  Each bit represents one 4 KiB frame.
 * Bit 0 = free, Bit 1 = used.
 *
 * The memory map is passed in by the bootloader (stivale2 or multiboot2).
 * We call pmm_init() with a list of free regions, then mark the kernel
 * and bitmap itself as used.
 */

/* Stivale2 memory map entry (subset we need) */
typedef struct {
    uint64_t base;
    uint64_t length;
    uint32_t type;   /* 1 = usable */
    uint32_t unused;
} PACKED pmm_mmap_entry_t;

void   pmm_init(pmm_mmap_entry_t *entries, size_t count, uint64_t mem_top);
void  *pmm_alloc(void);          /* Allocate one 4 KiB frame, returns physical addr */
void  *pmm_alloc_n(size_t n);    /* Allocate n contiguous frames */
void   pmm_free(void *addr);
void   pmm_free_n(void *addr, size_t n);
size_t pmm_free_frames(void);
size_t pmm_total_frames(void);
