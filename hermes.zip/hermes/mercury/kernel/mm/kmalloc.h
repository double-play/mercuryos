#pragma once
#include <stddef.h>

/* ─── Mercury OS ─ kernel/mm/kmalloc.h ───────────────────────────────── */

void  kmalloc_init(void);
void *kmalloc(size_t size);
void *kcalloc(size_t count, size_t size);
void  kfree(void *ptr);
