#pragma once
#include <stdint.h>
#include <stdbool.h>

/* ─── Mercury OS ─ kernel/mm/vmm.h ───────────────────────────────────── */

/* Page flags (stored in low 12 bits of PTE/PDE) */
#define VMM_PRESENT   (1ULL << 0)
#define VMM_WRITABLE  (1ULL << 1)
#define VMM_USER      (1ULL << 2)
#define VMM_WRITE_THR (1ULL << 3)
#define VMM_NO_CACHE  (1ULL << 4)
#define VMM_NX        (1ULL << 63)   /* No-Execute */

typedef uint64_t *page_table_t;   /* pointer to a 512-entry PML4/PDPT/PD/PT */

void   vmm_init(void);
void   vmm_map(page_table_t pml4, uintptr_t virt, uintptr_t phys, uint64_t flags);
void   vmm_unmap(page_table_t pml4, uintptr_t virt);
void   vmm_switch(page_table_t pml4);

/* Returns a new, empty address space with the kernel already mapped */
page_table_t vmm_new_space(void);
