/* ─── Mercury OS ─ kernel/mm/kmalloc.c ───────────────────────────────── */
/*
 * A simple free-list heap allocator for kernel use.
 *
 * Layout of a heap block (in memory):
 *   [ block_header_t | <user data ...> ]
 *
 * The heap grows by requesting whole pages from the PMM when it
 * runs out of space.  Freed blocks are coalesced with their right
 * neighbour when possible.
 */

#include "kmalloc.h"
#include "pmm.h"
#include "../mercury.h"
#include "../lib/kstring.h"

/* ── Block header ────────────────────────────────────────────────────── */
#define HEAP_MAGIC  0xDEADC0DEUL

typedef struct block_hdr {
    uint32_t        magic;
    size_t          size;    /* usable bytes (not including header) */
    bool            free;
    struct block_hdr *next;  /* next block in the free list */
} block_header_t;

#define HDR_SIZE    sizeof(block_header_t)
#define MIN_SPLIT   (HDR_SIZE + 16)    /* don't split if remainder < this */

/* ── Heap state ──────────────────────────────────────────────────────── */
/* We place the heap in virtual address space right after the kernel+PMM
   bitmap.  Start address is page-aligned and mapped on demand.         */
#define HEAP_VIRT_START  0xFFFFFFFF90000000ULL
#define HEAP_MAX         (64 * MiB)

static uintptr_t heap_current = HEAP_VIRT_START;  /* next unmapped page */
static block_header_t *heap_head = NULL;

/* ── Grow heap by n pages ─────────────────────────────────────────────── */
static void heap_grow(size_t pages) {
    extern void vmm_map(uint64_t *pml4, uintptr_t virt, uintptr_t phys, uint64_t flags);
    extern uint64_t *kernel_pml4;   /* defined in vmm.c — we reach it via extern */

    for (size_t i = 0; i < pages; i++) {
        if (heap_current - HEAP_VIRT_START >= HEAP_MAX)
            PANIC("kmalloc: heap exhausted (max %llu MiB)", HEAP_MAX / MiB);
        void *phys = pmm_alloc();
        /* Direct call to vmm_map on the kernel address space */
        typedef void (*vmm_map_fn)(uint64_t*, uintptr_t, uintptr_t, uint64_t);
        extern void vmm_map(uint64_t*, uintptr_t, uintptr_t, uint64_t);
        extern uint64_t kernel_pml4_phys;   /* see vmm.c */
        /* Use a simplified self-contained mmap via CR3 */
        /* We write directly into current page tables via PHYS_TO_VIRT */
        /* (Full VMM wiring happens in main kernel_main) */
        heap_current += PAGE_SIZE;
    }
    /* NOTE: For this starter kernel the heap is identity-mapped during
       vmm_init (first 4GiB). We just need to track the bump pointer.
       Replace heap_grow with vmm_map calls once user processes are added. */
}

/* ── Init ────────────────────────────────────────────────────────────── */
void kmalloc_init(void) {
    /* Allocate the first heap page */
    void *phys = pmm_alloc();
    /* The first 4 GiB is mapped by vmm_init, so physical == virtual here */
    heap_head = (block_header_t *)PHYS_TO_VIRT((uintptr_t)phys);
    heap_head->magic = HEAP_MAGIC;
    heap_head->size  = PAGE_SIZE - HDR_SIZE;
    heap_head->free  = true;
    heap_head->next  = NULL;
}

/* ── Alloc ───────────────────────────────────────────────────────────── */
void *kmalloc(size_t size) {
    if (size == 0) return NULL;
    /* Align to 16 bytes */
    size = (size + 15) & ~15UL;

    block_header_t *blk = heap_head;
    while (blk) {
        ASSERT(blk->magic == HEAP_MAGIC);
        if (blk->free && blk->size >= size) {
            /* Split block if there's enough room left */
            if (blk->size >= size + MIN_SPLIT) {
                block_header_t *split = (block_header_t *)((uint8_t *)blk + HDR_SIZE + size);
                split->magic = HEAP_MAGIC;
                split->size  = blk->size - size - HDR_SIZE;
                split->free  = true;
                split->next  = blk->next;
                blk->next    = split;
                blk->size    = size;
            }
            blk->free = false;
            return (void *)((uint8_t *)blk + HDR_SIZE);
        }
        /* If this is the last block and it's too small, expand heap */
        if (!blk->next) {
            size_t pages = (size + HDR_SIZE + PAGE_SIZE - 1) / PAGE_SIZE;
            void *phys   = pmm_alloc_n(pages);
            block_header_t *newblk = (block_header_t *)PHYS_TO_VIRT((uintptr_t)phys);
            newblk->magic = HEAP_MAGIC;
            newblk->size  = pages * PAGE_SIZE - HDR_SIZE;
            newblk->free  = true;
            newblk->next  = NULL;
            blk->next = newblk;
        }
        blk = blk->next;
    }
    PANIC("kmalloc: internal error (size=%zu)", size);
}

void *kcalloc(size_t count, size_t size) {
    void *ptr = kmalloc(count * size);
    kmemset(ptr, 0, count * size);
    return ptr;
}

/* ── Free + coalesce ─────────────────────────────────────────────────── */
void kfree(void *ptr) {
    if (!ptr) return;
    block_header_t *blk = (block_header_t *)((uint8_t *)ptr - HDR_SIZE);
    ASSERT(blk->magic == HEAP_MAGIC);
    ASSERT(!blk->free);   /* double-free detection */
    blk->free = true;
    /* Coalesce with next free block */
    while (blk->next && blk->next->free) {
        ASSERT(blk->next->magic == HEAP_MAGIC);
        blk->size += HDR_SIZE + blk->next->size;
        blk->next  = blk->next->next;
    }
}
