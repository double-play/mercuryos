/* ─── Mercury OS ─ kernel/lib/kstring.c ──────────────────────────────── */
/*
 * Freestanding replacements for the C string functions we need.
 * We cannot link against libc, so we provide our own.
 */

#include "../mercury.h"

size_t kstrlen(const char *s) {
    size_t n = 0;
    while (*s++) n++;
    return n;
}

int kstrcmp(const char *a, const char *b) {
    while (*a && (*a == *b)) { a++; b++; }
    return (unsigned char)*a - (unsigned char)*b;
}

int kstrncmp(const char *a, const char *b, size_t n) {
    for (; n && *a && (*a == *b); a++, b++, n--);
    return n ? ((unsigned char)*a - (unsigned char)*b) : 0;
}

char *kstrcpy(char *dst, const char *src) {
    char *d = dst;
    while ((*d++ = *src++));
    return dst;
}

char *kstrncpy(char *dst, const char *src, size_t n) {
    char *d = dst;
    while (n-- && (*d++ = *src++));
    while (n--) *d++ = '\0';
    return dst;
}

void *kmemset(void *ptr, int val, size_t n) {
    unsigned char *p = ptr;
    while (n--) *p++ = (unsigned char)val;
    return ptr;
}

void *kmemcpy(void *dst, const void *src, size_t n) {
    unsigned char       *d = dst;
    const unsigned char *s = src;
    while (n--) *d++ = *s++;
    return dst;
}

void *kmemmove(void *dst, const void *src, size_t n) {
    unsigned char       *d = dst;
    const unsigned char *s = src;
    if (d < s) {
        while (n--) *d++ = *s++;
    } else {
        d += n; s += n;
        while (n--) *--d = *--s;
    }
    return dst;
}

int kmemcmp(const void *a, const void *b, size_t n) {
    const unsigned char *p = a, *q = b;
    for (; n--; p++, q++)
        if (*p != *q) return (int)*p - (int)*q;
    return 0;
}
