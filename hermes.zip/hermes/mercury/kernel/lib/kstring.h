#pragma once
#include <stddef.h>

/* ─── Mercury OS ─ kernel/lib/kstring.h ──────────────────────────────── */

size_t kstrlen(const char *s);
int    kstrcmp(const char *a, const char *b);
int    kstrncmp(const char *a, const char *b, size_t n);
char  *kstrcpy(char *dst, const char *src);
char  *kstrncpy(char *dst, const char *src, size_t n);
void  *kmemset(void *ptr, int val, size_t n);
void  *kmemcpy(void *dst, const void *src, size_t n);
void  *kmemmove(void *dst, const void *src, size_t n);
int    kmemcmp(const void *a, const void *b, size_t n);
