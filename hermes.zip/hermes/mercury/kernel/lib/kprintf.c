/* ─── Mercury OS ─ kernel/lib/kprintf.c ──────────────────────────────── */

#include "../mercury.h"
#include "../drivers/vga.h"
#include <stdarg.h>
#include <stdint.h>
#include <stdbool.h>

/* ── Integer → string helpers ───────────────────────────────────────── */
static void print_u64(uint64_t n, int base, bool upper) {
    const char *digits_lo = "0123456789abcdef";
    const char *digits_up = "0123456789ABCDEF";
    const char *digits    = upper ? digits_up : digits_lo;
    char buf[65];
    int  i = 64;
    buf[i] = '\0';
    if (n == 0) { vga_putchar('0'); return; }
    while (n > 0) { buf[--i] = digits[n % (uint64_t)base]; n /= (uint64_t)base; }
    vga_puts(buf + i);
}

static void print_i64(int64_t n) {
    if (n < 0) { vga_putchar('-'); print_u64((uint64_t)(-n), 10, false); }
    else        { print_u64((uint64_t)n, 10, false); }
}

static void print_pad_hex(uint64_t n, int width) {
    /* Zero-padded hex, used for %p / %016llx style */
    char buf[17];
    int i = 16;
    buf[i] = '\0';
    for (; i > 0; i--) { buf[i-1] = "0123456789abcdef"[n & 0xF]; n >>= 4; }
    /* Find the start of significant digits but pad to width */
    int start = 16 - width;
    if (start < 0) start = 0;
    vga_puts(buf + start);
}

/* ── Core formatter ──────────────────────────────────────────────────── */
void kvprintf(const char *fmt, va_list ap) {
    for (; *fmt; fmt++) {
        if (*fmt != '%') { vga_putchar(*fmt); continue; }
        fmt++;
        /* Width / flags (minimal: just '0' prefix and width digit) */
        bool zero_pad = false;
        int  width    = 0;
        if (*fmt == '0') { zero_pad = true; fmt++; }
        while (*fmt >= '1' && *fmt <= '9') { width = width * 10 + (*fmt - '0'); fmt++; }
        /* Length modifiers */
        bool is_long = false, is_ll = false;
        if (*fmt == 'l') {
            is_long = true; fmt++;
            if (*fmt == 'l') { is_ll = true; fmt++; }
        }
        (void)zero_pad; (void)is_long; (void)is_ll; /* silence unused warnings */

        switch (*fmt) {
        case 'd': case 'i': print_i64((int64_t)va_arg(ap, int));      break;
        case 'u':           print_u64((uint64_t)va_arg(ap, unsigned), 10, false); break;
        case 'x':           print_u64((uint64_t)va_arg(ap, unsigned), 16, false); break;
        case 'X':           print_u64((uint64_t)va_arg(ap, unsigned), 16, true);  break;
        case 'o':           print_u64((uint64_t)va_arg(ap, unsigned), 8,  false); break;
        case 'b':           print_u64((uint64_t)va_arg(ap, unsigned), 2,  false); break;
        case 'p': {
            uintptr_t ptr = (uintptr_t)va_arg(ap, void *);
            vga_puts("0x");
            print_pad_hex(ptr, 16);
            break;
        }
        case 's': {
            const char *s = va_arg(ap, const char *);
            vga_puts(s ? s : "(null)");
            break;
        }
        case 'c':
            vga_putchar((char)va_arg(ap, int));
            break;
        case '%':
            vga_putchar('%');
            break;
        default:
            vga_putchar('%');
            vga_putchar(*fmt);
            break;
        }
    }
}

void kprintf(const char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    kvprintf(fmt, ap);
    va_end(ap);
}
