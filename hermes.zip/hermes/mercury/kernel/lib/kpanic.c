/* ─── Mercury OS ─ kernel/lib/kpanic.c ───────────────────────────────── */

#include "../mercury.h"
#include "../drivers/vga.h"

NORETURN void kpanic(const char *file, int line, const char *fmt, ...) {
    cli();   /* Disable interrupts immediately */

    /* Red-on-black panic screen */
    vga_set_color(VGA_WHITE, VGA_RED);
    vga_clear();

    vga_set_color(VGA_WHITE, VGA_RED);
    vga_puts("\n  *** MERCURY OS - KERNEL PANIC ***\n\n  ");

    va_list ap;
    va_start(ap, fmt);
    kvprintf(fmt, ap);
    va_end(ap);

    kprintf("\n\n  Location: %s : %d\n", file, line);
    kprintf("\n  System halted. Please reboot.\n");

    /* Halt forever */
    for (;;) {
        cli();
        hlt();
    }
}
