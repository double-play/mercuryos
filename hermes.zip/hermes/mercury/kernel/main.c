/* ─── Mercury OS ─ kernel/main.c ─────────────────────────────────────── */
/*
 * kernel_main() is called by the bootloader entry stub after setting up
 * a valid stack.  At this point we are in 64-bit long mode, paging is
 * active (bootloader-provided tables), and interrupts are disabled.
 *
 * Boot protocol: we support a minimal stivale2-style struct passed in rdi.
 * If you use GRUB/multiboot2, swap out the mmap parsing section below.
 */

#include "mercury.h"
#include "cpu/gdt.h"
#include "cpu/idt.h"
#include "mm/pmm.h"
#include "mm/vmm.h"
#include "mm/kmalloc.h"
#include "drivers/vga.h"
#include "drivers/timer.h"
#include "drivers/keyboard.h"

/* ── Stivale2 tag types we use ──────────────────────────────────────── */
#define STIVALE2_MMAP_USABLE        1
#define STIVALE2_STRUCT_TAG_MMAP_ID 0x2187f79e8612de07ULL

typedef struct {
    uint64_t base, length;
    uint32_t type;
    uint32_t unused;
} PACKED stivale2_mmap_entry_t;

typedef struct {
    uint64_t identifier;
    uint64_t next;
    uint64_t entries;
    stivale2_mmap_entry_t mmap[];
} PACKED stivale2_tag_mmap_t;

typedef struct {
    uint8_t  bootloader_brand[64];
    uint8_t  bootloader_version[64];
    uint64_t tags;   /* linked list of tag structs */
} PACKED stivale2_struct_t;

/* ── Tag walker ──────────────────────────────────────────────────────── */
static void *stivale2_get_tag(stivale2_struct_t *hdr, uint64_t id) {
    uint64_t *tag = (uint64_t *)hdr->tags;
    while (tag) {
        if (tag[0] == id) return tag;
        tag = (uint64_t *)tag[1];
    }
    return NULL;
}

/* ── Banner ──────────────────────────────────────────────────────────── */
static void print_banner(void) {
    vga_set_color(VGA_LIGHT_CYAN, VGA_BLACK);
    kprintf("  __  __                                  ___  ____\n");
    kprintf(" |  \\/  |  ___  _ __  ___  _   _  _ __  |_ _||  _ \\\n");
    kprintf(" | |\\/| | / _ \\| '__|/ __|| | | || '__|  | | | |_) |\n");
    kprintf(" | |  | ||  __/| |  | (__ | |_| || |     | | |  __/\n");
    kprintf(" |_|  |_| \\___||_|   \\___| \\__,_||_|    |___||_|\n");
    vga_set_color(VGA_DARK_GREY, VGA_BLACK);
    kprintf("\n  x86-64 Research Kernel  |  Build: " __DATE__ " " __TIME__ "\n");
    vga_set_color(VGA_LIGHT_GREY, VGA_BLACK);
    kprintf("  ────────────────────────────────────────────────────\n\n");
}

/* ── Mini shell ──────────────────────────────────────────────────────── */
#define CMD_MAX 128

static void shell_run(void) {
    char cmd[CMD_MAX];

    for (;;) {
        vga_set_color(VGA_LIGHT_GREEN, VGA_BLACK);
        kprintf("mercury");
        vga_set_color(VGA_LIGHT_GREY, VGA_BLACK);
        kprintf("$ ");
        vga_set_color(VGA_WHITE, VGA_BLACK);

        /* Read a line */
        int pos = 0;
        for (;;) {
            char c = keyboard_getchar();
            if (c == '\n') {
                vga_putchar('\n');
                break;
            }
            if (c == '\b') {
                if (pos > 0) { pos--; vga_putchar('\b'); vga_putchar(' '); vga_putchar('\b'); }
                continue;
            }
            if (pos < CMD_MAX - 1) { cmd[pos++] = c; vga_putchar(c); }
        }
        cmd[pos] = '\0';
        if (pos == 0) continue;

        vga_set_color(VGA_LIGHT_GREY, VGA_BLACK);

        /* ── Built-in commands ── */
        if (kstrncmp(cmd, "help", 4) == 0) {
            kprintf("  Built-in commands:\n");
            kprintf("    help     - show this message\n");
            kprintf("    uname    - kernel version\n");
            kprintf("    meminfo  - physical memory statistics\n");
            kprintf("    uptime   - ticks since boot\n");
            kprintf("    clear    - clear the screen\n");
            kprintf("    panic    - trigger a test kernel panic\n");
            kprintf("    halt     - halt the CPU\n");
        }
        else if (kstrncmp(cmd, "uname", 5) == 0) {
            kprintf("  Mercury OS  0.1.0-dev  x86-64\n");
        }
        else if (kstrncmp(cmd, "meminfo", 7) == 0) {
            size_t free_f  = pmm_free_frames();
            size_t total_f = pmm_total_frames();
            size_t used_f  = total_f - free_f;
            kprintf("  Total  : %u MiB  (%u frames)\n",
                    (unsigned)(total_f * PAGE_SIZE / MiB), (unsigned)total_f);
            kprintf("  Used   : %u KiB  (%u frames)\n",
                    (unsigned)(used_f * PAGE_SIZE / KiB),  (unsigned)used_f);
            kprintf("  Free   : %u MiB  (%u frames)\n",
                    (unsigned)(free_f * PAGE_SIZE / MiB),  (unsigned)free_f);
        }
        else if (kstrncmp(cmd, "uptime", 6) == 0) {
            uint64_t ms = timer_ticks();
            kprintf("  %llu ms  (%llu s)\n", ms, ms / 1000);
        }
        else if (kstrncmp(cmd, "clear", 5) == 0) {
            vga_clear();
        }
        else if (kstrncmp(cmd, "panic", 5) == 0) {
            PANIC("User-requested test panic from shell.");
        }
        else if (kstrncmp(cmd, "halt", 4) == 0) {
            vga_set_color(VGA_YELLOW, VGA_BLACK);
            kprintf("  Halting Mercury OS. Goodbye.\n");
            cli();
            for (;;) hlt();
        }
        else {
            vga_set_color(VGA_LIGHT_RED, VGA_BLACK);
            kprintf("  Unknown command: '%s'  (type 'help')\n", cmd);
            vga_set_color(VGA_LIGHT_GREY, VGA_BLACK);
        }
    }
}

/* ── Kernel entry ────────────────────────────────────────────────────── */
void kernel_main(stivale2_struct_t *bootinfo) {
    /* 1. VGA first — so we can print errors immediately */
    vga_init();
    print_banner();

    /* 2. CPU tables */
    vga_set_color(VGA_YELLOW, VGA_BLACK);
    kprintf("  [INIT] GDT");
    gdt_init();
    kprintf(" ... OK\n");

    kprintf("  [INIT] IDT + PIC");
    idt_init();
    kprintf(" ... OK\n");

    /* 3. Memory map from bootloader */
    kprintf("  [INIT] PMM");
    stivale2_tag_mmap_t *mmap_tag =
        (stivale2_tag_mmap_t *)stivale2_get_tag(bootinfo, STIVALE2_STRUCT_TAG_MMAP_ID);
    ASSERT(mmap_tag != NULL);

    /* Find top of physical memory */
    uint64_t mem_top = 0;
    for (uint64_t i = 0; i < mmap_tag->entries; i++) {
        stivale2_mmap_entry_t *e = &mmap_tag->mmap[i];
        uint64_t top = e->base + e->length;
        if (top > mem_top) mem_top = top;
    }

    pmm_init((pmm_mmap_entry_t *)mmap_tag->mmap, (size_t)mmap_tag->entries, mem_top);
    kprintf(" ... %u MiB free\n",
            (unsigned)(pmm_free_frames() * PAGE_SIZE / MiB));

    /* 4. Virtual memory */
    kprintf("  [INIT] VMM (4-level paging)");
    vmm_init();
    kprintf(" ... OK\n");

    /* 5. Kernel heap */
    kprintf("  [INIT] Heap (kmalloc)");
    kmalloc_init();
    kprintf(" ... OK\n");

    /* 6. Timer */
    kprintf("  [INIT] PIT timer (%d Hz)", TIMER_HZ);
    timer_init();
    kprintf(" ... OK\n");

    /* 7. Keyboard */
    kprintf("  [INIT] PS/2 keyboard");
    keyboard_init();
    kprintf(" ... OK\n");

    /* Enable interrupts */
    sti();

    vga_set_color(VGA_LIGHT_GREY, VGA_BLACK);
    kprintf("\n  All subsystems initialised. Booting into shell.\n\n");
    timer_sleep(300);

    /* Drop into the interactive shell */
    shell_run();

    /* Should never reach here */
    PANIC("kernel_main returned unexpectedly");
}
