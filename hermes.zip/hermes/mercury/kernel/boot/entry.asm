; ─── Mercury OS ─ kernel/boot/entry.asm ──────────────────────────────
; This is the raw ELF entry point (_start).
; At this point the CPU is already in 64-bit long mode (set up by Limine).
; We:
;   1. Disable interrupts (should already be disabled, just to be safe)
;   2. Set up a proper kernel stack
;   3. Zero the BSS segment
;   4. Call kernel_main(stivale2_struct_t *) — rdi holds the boot struct ptr

section .bss
align 16
stack_bottom:
    resb 32768      ; 32 KiB initial kernel stack
stack_top:

section .text
global _start
extern kernel_main

; BSS extents provided by the linker script
extern __bss_start
extern _end

_start:
    cli

    ; Set up our own stack (Limine provides one but we want to control it)
    mov rsp, stack_top
    mov rbp, rsp

    ; Zero the BSS section
    ; rdi already holds the stivale2 boot struct pointer — save it
    push rdi
    lea  rdi, [rel __bss_start]
    lea  rcx, [rel _end]
    sub  rcx, rdi
    xor  eax, eax
    rep  stosb
    pop  rdi                ; restore boot struct pointer

    ; Align stack to 16 bytes for System V ABI compliance
    and rsp, ~0xFULL

    ; Call the C kernel entry — rdi = stivale2 struct (already set)
    call kernel_main

    ; If kernel_main returns, halt forever
.hang:
    cli
    hlt
    jmp .hang
