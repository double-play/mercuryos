# Mercury OS

A custom x86-64 kernel written in C and NASM assembly.

```
  __  __                                  ___  ____
 |  \/  |  ___  _ __  ___  _   _  _ __  |_ _||  _ \
 | |\/| | / _ \| '__|/ __|| | | || '__|  | | | |_) |
 | |  | ||  __/| |  | (__ | |_| || |     | | |  __/
 |_|  |_| \___||_|   \___| \__,_||_|    |___||_|
```

## Features

| Subsystem | Details |
|-----------|---------|
| **Boot** | Limine bootloader (stivale2 protocol) |
| **CPU** | 64-bit GDT (null, kernel code/data, user code/data) |
| **Interrupts** | IDT with 20 CPU exception handlers + 16 IRQ handlers, PIC remapped to 0x20–0x2F |
| **Memory** | Bitmap PMM + 4-level (PML4) VMM + free-list kmalloc/kfree |
| **Drivers** | VGA text mode (80×25), PIT timer (1000 Hz), PS/2 keyboard (US layout) |
| **Shell** | Interactive kernel shell with `help`, `meminfo`, `uptime`, `clear`, `panic`, `halt` |

---

## Project layout

```
mercury/
├── Makefile
├── boot/
│   └── limine.cfg
└── kernel/
    ├── mercury.h          ← core types, macros, port I/O
    ├── main.c             ← kernel_main(), shell
    ├── linker.ld
    ├── boot/
    │   └── entry.asm      ← _start, stack setup, BSS zero
    ├── cpu/
    │   ├── gdt.c/h        ← Global Descriptor Table
    │   ├── gdt_flush.asm  ← far-return CS reload
    │   ├── idt.c/h        ← Interrupt Descriptor Table + PIC
    │   └── idt_stubs.asm  ← ISR/IRQ entry trampolines
    ├── mm/
    │   ├── pmm.c/h        ← Physical Memory Manager (bitmap)
    │   ├── vmm.c/h        ← Virtual Memory Manager (4-level paging)
    │   └── kmalloc.c/h    ← Kernel heap allocator
    ├── drivers/
    │   ├── vga.c/h        ← VGA text mode (80×25)
    │   ├── timer.c/h      ← PIT 8253 (1000 Hz tick)
    │   └── keyboard.c/h   ← PS/2 keyboard (scancode set 1)
    └── lib/
        ├── kprintf.c      ← kprintf / kvprintf
        ├── kpanic.c       ← PANIC macro + red screen
        └── kstring.c/h    ← freestanding string/memory utils
```

---

## Building on WSL

### 1 — Install dependencies

```bash
sudo apt update
sudo apt install build-essential nasm qemu-system-x86 xorriso

# Option A: cross-compiler (recommended — cleanest build)
sudo apt install gcc-x86-64-linux-gnu binutils-x86-64-linux-gnu

# Option B: native gcc with multilib (works fine for the kernel)
sudo apt install gcc-multilib
```

### 2 — Build

```bash
cd mercury
make
```

You should see `mercury.elf` produced with no errors.

### 3 — Run in QEMU (fastest way to test)

```bash
make run
```

QEMU boots the ELF directly. You will see the Mercury banner and then the
`mercury$` shell prompt.

### 4 — Build a bootable ISO (for Limine on real hardware or QEMU CDROM)

```bash
# Download Limine binaries first
git clone https://github.com/limine-bootloader/limine.git --branch=v4.x-branch-binary --depth=1
cp limine/limine-cd.bin    iso/boot/
cp limine/limine-cd-efi.bin iso/boot/

make iso
make run-iso
```

---

## Shell commands

| Command | Description |
|---------|-------------|
| `help` | List all commands |
| `uname` | Kernel name and version |
| `meminfo` | Physical memory stats (total / used / free) |
| `uptime` | Milliseconds and seconds since boot |
| `clear` | Clear the screen |
| `panic` | Trigger a test kernel panic (red screen) |
| `halt` | Gracefully halt the CPU |

---

## Next steps (suggested extensions)

- **Processes** — task struct, context switch (`kernel/proc/`)
- **Scheduler** — round-robin or priority queue
- **Syscalls** — `int 0x80` / `syscall` MSR entry
- **VFS** — virtual filesystem layer
- **initrd** — RAM disk loaded by Limine to serve as early root
- **Serial** — COM1 UART for remote debugging / logging
- **ACPI** — power management, APIC table parsing
- **SMP** — bring up application processors via the LAPIC

---

## Debugging in QEMU

```bash
# Start QEMU waiting for GDB on port 1234
qemu-system-x86_64 -kernel mercury.elf -m 256M -s -S &

# In another terminal
gdb mercury.elf
(gdb) target remote :1234
(gdb) break kernel_main
(gdb) continue
```
